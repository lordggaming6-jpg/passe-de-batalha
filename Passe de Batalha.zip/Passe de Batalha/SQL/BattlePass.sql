-- ============================================================
--  PASSE DE BATALHA - instalacao / atualizacao do banco
--  Execute UMA vez no banco usado pela conexao Lua (ex.: MuOnline).
--  Pode rodar de novo quantas vezes quiser: so cria o que falta
--  e NAO apaga pontos nem resgates existentes.
--  (Faca backup antes, como sempre.)
--
--  CORRECAO: a versao anterior deste arquivo nao criava as colunas
--  Kills / OnlineSeconds nem a tabela BattlePassOnlineSession, que o
--  servidor usa. Sem elas a consulta falhava e o cliente mostrava
--  "Banco indisponivel" com tudo zerado.
-- ============================================================
SET XACT_ABORT ON;
BEGIN TRY
BEGIN TRANSACTION;

-- 1) Progresso do jogador na temporada --------------------------------
IF OBJECT_ID(N'dbo.BattlePassProgress', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.BattlePassProgress (
        Season int NOT NULL,
        AccountID varchar(64) NOT NULL,
        Donate bit NOT NULL CONSTRAINT DF_BattlePassProgress_Donate DEFAULT (0),
        Points int NOT NULL CONSTRAINT DF_BattlePassProgress_Points DEFAULT (0),
        Kills int NOT NULL CONSTRAINT DF_BattlePassProgress_Kills DEFAULT (0),
        OnlineSeconds int NOT NULL CONSTRAINT DF_BattlePassProgress_OnlineSeconds DEFAULT (0),
        CONSTRAINT PK_BattlePassProgress PRIMARY KEY (Season, AccountID),
        CONSTRAINT CK_BattlePassProgress_Points CHECK (Points >= 0)
    );
END;

-- 2) Premios ja resgatados --------------------------------------------
IF OBJECT_ID(N'dbo.BattlePassClaim', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.BattlePassClaim (
        Season int NOT NULL,
        AccountID varchar(64) NOT NULL,
        Track varchar(4) NOT NULL,
        Level int NOT NULL,
        PointsRequired int NOT NULL,
        Reward int NOT NULL,
        CurrencyTable varchar(128) NOT NULL,
        CurrencyColumn varchar(128) NOT NULL,
        ClaimedAt datetime NOT NULL CONSTRAINT DF_BattlePassClaim_ClaimedAt DEFAULT (GETUTCDATE()),
        CONSTRAINT PK_BattlePassClaim PRIMARY KEY (Season, AccountID, Track, Level),
        CONSTRAINT CK_BattlePassClaim_Track CHECK (Track IN ('free', 'vip', 'don')),
        CONSTRAINT FK_BattlePassClaim_Progress FOREIGN KEY (Season, AccountID)
            REFERENCES dbo.BattlePassProgress (Season, AccountID)
    );
END;

-- 3) Tempo online (usado pelas missoes de "minutos online") -----------
-- Se ja existir uma versao ANTIGA desta tabela (sem Season/AccountID/SavedSeconds/SessionID),
-- ela e apenas renomeada (nada e apagado) e uma tabela nova e criada.
-- E seguro: o tempo acumulado fica em BattlePassProgress.OnlineSeconds; esta tabela so
-- guarda o controle temporario de cada sessao de jogo.
IF OBJECT_ID(N'dbo.BattlePassOnlineSession', N'U') IS NOT NULL
   AND (COL_LENGTH('dbo.BattlePassOnlineSession', 'SessionID') IS NULL
     OR COL_LENGTH('dbo.BattlePassOnlineSession', 'Season') IS NULL
     OR COL_LENGTH('dbo.BattlePassOnlineSession', 'AccountID') IS NULL
     OR COL_LENGTH('dbo.BattlePassOnlineSession', 'SavedSeconds') IS NULL)
BEGIN
    DECLARE @oldName sysname = N'BattlePassOnlineSession_old_' + CONVERT(varchar(14), GETDATE(), 112) + REPLACE(CONVERT(varchar(8), GETDATE(), 108), ':', '');
    EXEC sp_rename N'dbo.BattlePassOnlineSession', @oldName;
END;

IF OBJECT_ID(N'dbo.BattlePassOnlineSession', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.BattlePassOnlineSession (
        SessionID int IDENTITY(1,1) NOT NULL,
        Season int NOT NULL,
        AccountID varchar(64) NOT NULL,
        SavedSeconds int NOT NULL CONSTRAINT DF_BPOnlineSession_v2_Saved DEFAULT (0),
        CreatedAt datetime NOT NULL CONSTRAINT DF_BPOnlineSession_v2_Created DEFAULT (GETUTCDATE()),
        CONSTRAINT PK_BPOnlineSession_v2 PRIMARY KEY (SessionID)
    );
END;

-- 4) Atualiza instalacoes antigas (preserva tudo) ---------------------
IF COL_LENGTH('dbo.BattlePassProgress', 'Donate') IS NULL
    ALTER TABLE dbo.BattlePassProgress ADD Donate bit NOT NULL CONSTRAINT DF_BattlePassProgress_Donate DEFAULT (0);
IF COL_LENGTH('dbo.BattlePassProgress', 'Kills') IS NULL
    ALTER TABLE dbo.BattlePassProgress ADD Kills int NOT NULL CONSTRAINT DF_BattlePassProgress_Kills DEFAULT (0);
IF COL_LENGTH('dbo.BattlePassProgress', 'OnlineSeconds') IS NULL
    ALTER TABLE dbo.BattlePassProgress ADD OnlineSeconds int NOT NULL CONSTRAINT DF_BattlePassProgress_OnlineSeconds DEFAULT (0);

IF EXISTS (SELECT 1 FROM sys.check_constraints WHERE name='CK_BattlePassClaim_Track' AND parent_object_id=OBJECT_ID('dbo.BattlePassClaim'))
    ALTER TABLE dbo.BattlePassClaim DROP CONSTRAINT CK_BattlePassClaim_Track;
ALTER TABLE dbo.BattlePassClaim WITH CHECK ADD CONSTRAINT CK_BattlePassClaim_Track CHECK (Track IN ('free', 'vip', 'don'));

COMMIT;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT>0 ROLLBACK;
    THROW;
END CATCH;

-- Conferencia: deve listar as 3 tabelas e as colunas Kills / OnlineSeconds.
SELECT TABLE_NAME, COLUMN_NAME
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME IN ('BattlePassProgress','BattlePassClaim','BattlePassOnlineSession')
ORDER BY TABLE_NAME, ORDINAL_POSITION;
