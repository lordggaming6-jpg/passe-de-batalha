-- Interface do passe. Premios, requisitos e autorizacao pertencem ao servidor.
-- Trilhas: 0 = FREE (gratis), 1 = VIP, 2 = DONATE. Cada uma pode dar Cash e/ou itens.
BattlePassUI = {}
local U = BattlePassUI
U.Config = {Enabled=true, Packet=221, Shortcut=66, -- B; ajuste caso exista conflito.
    ShowItemIcons=true} -- false = mostra so o nome do item (sem icone 3D)
local C = U.Config
local S = {Open=false, Sequence=0, Page=0, Rows={}, Message='', Missions=false}
local controls, incoming = {}, nil
local shortcutDown = false
local X,Y,W,H = 50,72,540,350 -- Y maior = janela mais baixa
local BACKGROUND = 620122
local imagesLoaded = false
local gold,white,muted,green,red = {238,196,104},{225,225,220},{150,148,143},{147,218,153},{230,120,110}
local TRACK_NAME = {[0]='FREE',[1]='VIP',[2]='DONATE'}
-- Pacote: trilha 0/1/2 do servidor vira 1/2/3 no protocolo de itens.
local native = {1,2,3,4,6,7,8,9,10,11,12,13,14,15,16,21,33,34,35,36,39,57,63,65,72,73,74,75,77,78,79}
local function yes(v) return v == true or v == 1 end
local function blocked()
    if UICustomInterface and UICustomInterface ~= 0 then return true end
    for _,id in ipairs(native) do if CheckWindowOpen(id)==1 then return true end end
    if UIChatWindow and CheckWindowOpen(UIChatWindow)==1 then return true end
    if QuestSystem and QuestSystem.CheckOpen and yes(QuestSystem.CheckOpen()) then return true end
    if QuestSystemNpc and QuestSystemNpc.CheckOpen and yes(QuestSystemNpc.CheckOpen()) then return true end
    if Shop and Shop.IsOpen and yes(Shop.IsOpen()) then return true end
    if GuardiaoBrindes and GuardiaoBrindes.CheckOpen and yes(GuardiaoBrindes.CheckOpen()) then return true end
    if LogInAndWinVisible == 1 then return true end
    return false
end
function U.CheckOpen() return S.Open and 1 or 0 end
local function over(x,y,w,h) return MousePosX()>=x and MousePosX()<=x+w and MousePosY()>=y and MousePosY()<=y+h end
local function bar(x,y,w,h,c)
    EnableAlphaTest(); SetBlend(); glColor4f(unpack(c)); DrawBar(x,y,w,h); EndDrawBar()
    GLSwitchBlend(); GLSwitch(); glColor3f(1,1,1); DisableAlphaBlend()
end
local function text(x,y,s,w,color,align)
    EnableAlphaTest(); SetFontType(1); SetTextBg(0,0,0,0); SetTextColor(color[1],color[2],color[3],255)
    RenderText3(x,y,tostring(s),w,align or 1); DisableAlphaBlend()
end
local function frame(x,y,w,h,highlight)
    bar(x,y,w,h,highlight and {.72,.53,.20,1} or {.34,.28,.17,1})
    bar(x+1,y+1,w-2,h-2,{.035,.045,.06,.98})
end
local function button(x,y,w,h,label,enabled,action)
    local hover=enabled and over(x,y,w,h)
    frame(x,y,w,h,hover)
    bar(x+2,y+2,w-4,h-4,enabled and {.24,.17,.07,1} or {.10,.10,.11,1})
    text(x+2,y+(h-10)/2,label,w-4,enabled and gold or muted,3)
    if enabled then controls[#controls+1]={x=x,y=y,w=w,h=h,action=action} end
end
-- action: 1 atualizar | 2 resgatar FREE | 3 resgatar VIP | 4 resgatar DONATE | 5 comprar Donate
local function request(action,level)
    if not S.Open or S.Waiting or blocked() then return end
    S.Sequence=S.Sequence%2147483646+1
    S.Waiting=true; S.Sent=os.time(); S.Valid=false; S.Action=action; S.Confirm=nil
    S.Message=action==1 and 'Atualizando...' or action==5 and 'Comprando...' or 'Resgatando...'
    incoming={Rows={}}
    local n='BPQ-'..UserGetName(); CreatePacket(n,C.Packet)
    SetBytePacket(n,action); SetDwordPacket(n,S.Sequence); SetBytePacket(n,level or 0)
    SendPacket(n); ClearPacket(n)
end
function U.Close()
    if not S.Open then return end
    S.Open=false; S.Waiting=false; S.Valid=false; S.Confirm=nil; S.Sequence=S.Sequence%2147483646+1
    controls={}; incoming=nil; DisableClickClient(); SetUnlockInterfaces()
end
function U.LoadImages()
    if imagesLoaded then return end
    LoadImage('Custom\\Interface\\BattlePassFundo.jpg',BACKGROUND)
    imagesLoaded = true
end
function U.Open()
    if not C.Enabled or blocked() then return end
    if not imagesLoaded then U.LoadImages() end
    S.Open=true; S.Name=UserGetName(); S.Page=0; S.Rows={}; S.Valid=false; S.Waiting=false; S.Missions=false; S.Confirm=nil
    S.Message='Carregando...'; controls={}; SetLockInterfaces(); DisableClickClient(); request(1)
end
local function readstr(n) return GetCharPacketLength(n,-1,GetBytePacket(n,-1)) end
function U.Protocol(number,n)
    if number~=C.Packet or n~='BP-'..UserGetName() then return end
    local sequence,kind=GetDwordPacket(n,-1),GetBytePacket(n,-1)
    -- Aviso do servidor ao digitar o comando do passe: abre a janela.
    if kind==4 then ClearPacket(n); if not S.Open then U.Open() end; return true end
    if not S.Open or not S.Waiting or sequence~=S.Sequence or S.Name~=UserGetName() then ClearPacket(n); return true end
    local v=incoming
    if kind==1 then
        v.Season=GetDwordPacket(n,-1); v.Points=GetDwordPacket(n,-1)
        v.Active=GetBytePacket(n,-1)==1; v.Vip=GetBytePacket(n,-1)==1; v.Donate=GetBytePacket(n,-1)==1
        v.Count=GetBytePacket(n,-1); v.Currency=readstr(n)
        v.Kills=GetDwordPacket(n,-1); v.OnlineSeconds=GetDwordPacket(n,-1)
        v.BuyEnabled=GetBytePacket(n,-1)==1; v.BuyPrice=GetDwordPacket(n,-1); v.BuyName=readstr(n)
        v.Started=true
    elseif kind==2 and v.Started then
        local i=GetBytePacket(n,-1)
        local row={Required=GetDwordPacket(n,-1),Titles={},Details={},Items={[0]={},[1]={},[2]={}},Total={},Claimed={}}
        for number=0,2 do row.Titles[number]=readstr(n); row.Details[number]=readstr(n) end
        row.Kills=GetDwordPacket(n,-1); row.Minutes=GetDwordPacket(n,-1)
        for number=0,2 do row.Claimed[number]=GetBytePacket(n,-1)==1 end
        if i>=1 and i<=v.Count and not v.Rows[i] then v.Rows[i]=row else v.Invalid=true end
    elseif kind==5 and v.Started then
        -- Itens do premio, em blocos de ate 5: nivel, trilha(1-3), total, inicio, quantidade.
        local i,track,total,start,count=GetBytePacket(n,-1),GetBytePacket(n,-1),GetBytePacket(n,-1),GetBytePacket(n,-1),GetBytePacket(n,-1)
        local row=v.Rows[i]; local number=track-1
        if not row or number<0 or number>2 or start~=#row.Items[number]+1 then v.Invalid=true
        else
            row.Total[number]=total
            for _=1,count do
                local item={Index=GetDwordPacket(n,-1)}
                item.Level=GetBytePacket(n,-1); item.Count=GetBytePacket(n,-1); item.Skill=GetBytePacket(n,-1)
                item.Luck=GetBytePacket(n,-1); item.Option=GetBytePacket(n,-1); item.Excellent=GetBytePacket(n,-1)
                item.Ancient=GetBytePacket(n,-1); item.JoH=GetBytePacket(n,-1); item.SockBonus=GetBytePacket(n,-1)
                item.Name=readstr(n)
                row.Items[number][#row.Items[number]+1]=item
            end
        end
    elseif kind==3 then
        local message=readstr(n); S.Waiting=false; S.LastUpdate=os.time()
        local complete=v.Started and not v.Invalid and v.Count>=1 and v.Count<=100
        if complete then
            for i=1,v.Count do
                local row=v.Rows[i]
                if not row then complete=false; break end
                for number=0,2 do if (row.Total[number] or 0)~=#row.Items[number] then complete=false end end
            end
        end
        if complete then
            S.Rows=v.Rows; S.Season=v.Season; S.Points=v.Points; S.Active=v.Active; S.Vip=v.Vip; S.Donate=v.Donate; S.Currency=v.Currency
            S.Kills=v.Kills; S.Online=v.OnlineSeconds; S.BuyEnabled=v.BuyEnabled; S.BuyPrice=v.BuyPrice; S.BuyName=v.BuyName
            S.Page=math.min(S.Page,math.floor((#S.Rows-1)/5)); S.Valid=true
            S.Message=message~='' and message or (S.Active and 'Passe o mouse em um premio para ver os itens.' or 'Temporada fora do periodo ativo.')
        else S.Valid=false; S.Message=message~='' and message or 'Resposta incompleta. Clique em atualizar.' end
        incoming=nil
    end
    ClearPacket(n); return true
end
function U.Update()
    if not S.Open then return end
    if not C.Enabled or S.Name~=UserGetName() or blocked() then U.Close(); return end
    if S.Confirm and os.time()-S.Confirm>=5 then S.Confirm=nil end
    if S.Waiting and os.time()-S.Sent>=8 then
        S.Waiting=false; S.Valid=false; incoming=nil; S.LastUpdate=os.time()
        S.Message='Sem resposta. Atualize antes de resgatar novamente.'
    end
end
-- Texto curto do item para o tooltip: nome, +nivel e opcoes.
local function itemLine(item)
    local t=(item.Count>1 and (item.Count..'x ') or '')..item.Name
    if item.Level>0 then t=t..' +'..item.Level end
    if item.Skill>0 then t=t..' +Skill' end
    if item.Luck>0 then t=t..' +Luck' end
    if item.Option>0 then t=t..' +Opt'..(item.Option*4) end
    if item.Excellent>0 then t=t..' +Exc' end
    if item.Ancient>0 then t=t..' +Anc' end
    if item.JoH>0 then t=t..' +Harmony' end
    if item.SockBonus>0 then t=t..' +Socket' end
    return t
end
local function missionDone(row)
    return (S.Kills or 0)>=row.Kills and (S.Online or 0)>=row.Minutes*60
end
local function tooltip()
    local t=S.Tip; S.Tip=nil
    if not t then return end
    local row,number=t.row,t.number
    local lines={{TRACK_NAME[number]..' - NIVEL '..t.level,gold}}
    local items=row.Items[number]
    if #items==0 then lines[#lines+1]={row.Titles[number]..' '..(S.Currency or ''),white}
    else
        for _,item in ipairs(items) do lines[#lines+1]={itemLine(item),white} end
        if row.Details[number]:sub(1,1)=='+' and row.Details[number]:find(S.Currency or '',1,true) then lines[#lines+1]={row.Details[number],gold} end
    end
    if not t.pointsOk then lines[#lines+1]={'Faltam pontos para este nivel.',red}
    elseif not t.missionOk then lines[#lines+1]={'Complete as missoes do nivel (botao MISSOES).',red}
    elseif number==1 and not S.Vip then lines[#lines+1]={'Requer VIP do jogo.',red}
    elseif number==2 and not S.Donate then lines[#lines+1]={'Requer o Donate.',red} end
    local w=60
    for _,l in ipairs(lines) do w=math.max(w,#l[1]*6+14) end
    local h=#lines*13+8
    local tx=math.min(MousePosX()+14,X+W-w-4); local ty=math.min(MousePosY()+14,Y+H-h-4)
    frame(tx,ty,w,h,true)
    for i,l in ipairs(lines) do text(tx+6,ty+5+(i-1)*13,l[1],w-10,l[2]) end
end
local function none(v) return (v or 0)==0 and 255 or v end -- 255 = "sem" para Ancient/JoH/Socket
-- "+ 25 Cash" -> "+25","Cash"; "ITEM"/"x2" -> texto,"".
local function splitDetail(d)
    local a,c=(d or ''):match('^%+ (%d+) (.+)$')
    if a then return '+'..a,c end
    return d or '',''
end
local function reward(x,y,w,h,row,number,claimed,unlocked,level,pointsOk,missionOk)
    local can=S.Valid and S.Active and not S.Waiting and unlocked and not claimed
    frame(x,y,w,h,can and over(x,y,w,h))
    bar(x+2,y+2,w-4,h-4,number==2 and {.16,.10,.04,1} or number==1 and {.12,.055,.16,1} or {.055,.08,.12,1})
    bar(x+3,y+3,w-6,1,{.66,.48,.22,.8})
    local items=row.Items[number]
    local color=unlocked and gold or muted
    if #items>0 and C.ShowItemIcons then
        -- Premio com item: icone do item a esquerda, quantidade/Cash a direita.
        frame(x+4,y+5,28,27,false)
        local item=items[1]
        S.Icons[#S.Icons+1]={X=x+5,Y=y+6,Item=item}
        if S.Valid and over(x+5,y+6,26,25) then S.IconHover=item end
        local l1,l2=splitDetail(row.Details[number])
        text(x+34,y+9,l1:sub(1,8),w-36,color,3)
        text(x+34,y+21,l2:sub(1,8),w-36,white,3)
    else
        text(x+3,y+6,(row.Titles[number] or ''):sub(1,14),w-6,color,3)
        text(x+3,y+18,(#items>0 and (row.Details[number] or '') or (S.Currency or '')):sub(1,14),w-6,white,3)
    end
    local label=claimed and 'RESGATADO' or can and 'RESGATAR' or 'BLOQUEADO'
    text(x+2,y+h-14,label,w-4,claimed and green or can and gold or muted,3)
    if S.Valid and over(x,y,w,h) then S.Tip={row=row,number=number,level=level,pointsOk=pointsOk,missionOk=missionOk} end
    if can then controls[#controls+1]={x=x,y=y,w=w,h=h,action=function() request(number==2 and 4 or number==1 and 3 or 2,level) end} end
end
-- Icones 3D desenhados depois do painel (mesma funcao nativa usada na quest).
local function drawIcons()
    for _,ic in ipairs(S.Icons) do
        local it=ic.Item
        DisableAlphaBlend()
        CreateItem(ic.X,ic.Y,26,25,it.Index,it.Level,it.Excellent,none(it.Ancient),1)
    end
    if S.IconHover then
        local it=S.IconHover; S.Tip=nil
        EnableAlphaTest(); glColor4f(1,1,1,1)
        -- ordem nativa: Op1(Skill), Op2(Luck), Life(Option), Exc, Ancient, JoH, SocketBonus, Sock1-5
        ShowDescriptionComplete(MousePosX()+20,MousePosY(),it.Index,it.Level,it.Skill,it.Luck,it.Option,it.Excellent,
            none(it.Ancient),none(it.JoH),none(it.SockBonus),255,255,255,255,255)
        DisableAlphaBlend()
    end
end
local function missionRows(first)
    for slot=1,5 do
        local i=first+slot-1; local v=S.Rows[i]
        if v then
            local ry=Y+138+(slot-1)*32
            frame(X+20,ry,W-40,28,false)
            text(X+30,ry+9,'NIVEL '..i,60,gold)
            local pOk=(S.Points or 0)>=v.Required
            text(X+100,ry+9,'Pontos '..(S.Points or 0)..'/'..v.Required,120,pOk and green or white)
            if v.Kills==0 and v.Minutes==0 then
                text(X+240,ry+9,'Sem missao extra',200,muted)
            else
                local kOk=(S.Kills or 0)>=v.Kills; local oOk=(S.Online or 0)>=v.Minutes*60
                text(X+240,ry+9,'Mortes '..math.min(S.Kills or 0,v.Kills)..'/'..v.Kills,110,kOk and green or white)
                text(X+360,ry+9,'Online '..math.min(math.floor((S.Online or 0)/60),v.Minutes)..'/'..v.Minutes..' min',150,oOk and green or white)
            end
        end
    end
end
function U.Render()
    U.Update(); controls={}; if not S.Open then return end
    S.Icons={}; S.IconHover=nil
    frame(X,Y,W,H,true)
    EnableAlphaTest(); glColor4f(1,1,1,1)
    RenderImage2(BACKGROUND,X+1,Y+1,W-2,H-2,0,0,1,1,1,1,1); DisableAlphaBlend()
    text(X+57,Y+13,'PASSE DE BATALHA',W-115,gold)
    button(X+W-28,Y+6,20,19,'X',true,U.Close)
    text(X+110,Y+44,'TEMPORADA '..tostring(S.Season or '-'),150,muted)
    local level=0
    for i,v in ipairs(S.Rows) do if (S.Points or 0)>=v.Required then level=i end end
    text(X+20,Y+68,tostring(level),71,gold,3); text(X+20,Y+92,'NIVEL',71,white,3)
    text(X+110,Y+61,'EXP DO PASSE',170,gold)
    local nextLevel=S.Rows[level+1]
    local target=nextLevel and nextLevel.Required or (S.Rows[#S.Rows] and S.Rows[#S.Rows].Required or 0)
    local previous=level>0 and S.Rows[level].Required or 0
    local ratio=target>previous and math.max(0,math.min(1,((S.Points or 0)-previous)/(target-previous))) or (target>0 and 1 or 0)
    frame(X+110,Y+79,214,12,false); bar(X+112,Y+81,210*ratio,8,{.76,.52,.16,1})
    text(X+110,Y+96,tostring(S.Points or 0)..' / '..tostring(target)..' pontos',214,white)
    -- Caixa de status: VIP do jogo e Donate (com botao de compra).
    bar(X+342,Y+91,180,30,{0,0,0,.80})
    text(X+346,Y+94,S.Vip and 'VIP DO JOGO ATIVO' or 'NECESSITA VIP DO JOGO',172,S.Vip and green or muted,3)
    if S.Donate then text(X+346,Y+108,'DONATE ATIVO',172,green,3)
    elseif S.Valid and S.Active and S.BuyEnabled then
        local label=S.Confirm and ('CONFIRMAR? '..S.BuyPrice..' '..(S.BuyName or '')) or ('COMPRAR DONATE '..S.BuyPrice..' '..(S.BuyName or ''))
        button(X+344,Y+105,176,15,label:sub(1,30),not S.Waiting,function()
            if S.Confirm then request(5,0) else S.Confirm=os.time() end
        end)
    else text(X+346,Y+108,'DONATE INATIVO',172,muted,3) end
    local first=S.Page*5+1
    if S.Missions then
        text(X+20,Y+122,'MISSOES POR NIVEL',200,gold)
        missionRows(first)
    else
        text(X+16,Y+182,'GRATIS',68,{236,160,85},3)
        text(X+16,Y+233,'VIP',68,{226,232,242},3)
        text(X+16,Y+284,'DONATE',68,{255,215,100},3)
        for slot=1,5 do
            local i=first+slot-1; local v=S.Rows[i]
            if v then
                local rx=X+92+(slot-1)*86
                local pointsOk=(S.Points or 0)>=v.Required
                local missionOk=missionDone(v)
                local ok=pointsOk and missionOk
                text(rx,Y+133,'NIVEL '..i,81,gold,3)
                reward(rx,Y+148,80,47,v,0,v.Claimed[0],ok,i,pointsOk,missionOk)
                reward(rx,Y+199,80,47,v,1,v.Claimed[1],ok and S.Vip,i,pointsOk,missionOk)
                reward(rx,Y+250,80,47,v,2,v.Claimed[2],ok and S.Donate,i,pointsOk,missionOk)
                text(rx,Y+298,v.Required..' pts',80,muted,3)
            end
        end
    end
    button(X+92,Y+311,24,18,'<',S.Page>0 and not S.Waiting,function() S.Page=S.Page-1 end)
    text(X+120,Y+315,math.min(S.Page+1,math.max(1,math.ceil(#S.Rows/5)))..' / '..math.max(1,math.ceil(#S.Rows/5)),70,muted,3)
    button(X+194,Y+311,24,18,'>',first+4<#S.Rows and not S.Waiting,function() S.Page=S.Page+1 end)
    button(X+286,Y+310,112,20,S.Missions and 'PREMIOS' or 'MISSOES',S.Valid,function() S.Missions=not S.Missions end)
    button(X+404,Y+310,112,20,'ATUALIZAR',not S.Waiting,function() request(1) end)
    text(X+16,Y+335,(S.Message or ''):sub(1,90),W-32,white)
    drawIcons()
    tooltip()
end
function U.Mouse()
    if not S.Open then return end
    if blocked() then U.Close(); return end
    SetLockInterfaces()
    local click=CheckClickClient()==1; DisableClickClient()
    if not click then return end
    for _,v in ipairs(controls) do
        if over(v.x,v.y,v.w,v.h) then v.action(); controls={}; return end
    end
end
function U.Keys()
    local pressed=CheckPressedKey(C.Shortcut)==1
    local held=pressed or (CheckRepeatKey and CheckRepeatKey(C.Shortcut)==1)
    local toggle=pressed and not shortcutDown; shortcutDown=held
    if not C.Enabled then if S.Open then U.Close() end; return end
    if blocked() then if S.Open then U.Close() end; return end
    if S.Open and CheckPressedKey(Keys.Escape)==1 then U.Close(); return end
    if toggle then DisableClickClient(); if S.Open then U.Close() else U.Open() end end
end
InterfaceController.LoadImages(U.LoadImages)
InterfaceController.ClientProtocol(U.Protocol)
InterfaceController.BeforeMainProc(U.Render)
InterfaceController.UpdateMouse(U.Mouse)
InterfaceController.UpdateKey(U.Keys)
InterfaceController.UpdateProc(U.Update)
return U
